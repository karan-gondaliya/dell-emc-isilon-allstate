"""Module for NFS Export Stats"""

import re
from urllib.parse import quote

from datadog_checks.base import ConfigurationError

from .cds_dell_emc_consts import INTEGRATION_PREFIX, REQUEST_FAILED_MESSAGE

# OneFS lists only the exports of the System access zone when no zone is given.
DEFAULT_NFS_ZONE = "System"
ZONE_EXPORT_IDS_EXAMPLE = '{"Zone1": "1,3", "Zone2": "-2", "Zone3": ""}'
# Zone names are sent as a comma-separated list, so they cannot contain a comma. Control characters are never valid.
INVALID_ZONE_NAME_CHARACTERS = re.compile(r"[,\x00-\x1f\x7f]")
EXPORT_ID_TOKEN = re.compile(r"-?[0-9]+")


class CDSDellEMCNFSExportStatsHelper(object):
    """Class for NFS Export Stats"""

    def __init__(self, instance: object):
        self.nfs_export_stats_prefix = "{}{}".format(INTEGRATION_PREFIX, "nfs_export_stats_details.")
        self.instance = instance
        # {zone: (export IDs, exclude)} parsed from zone_export_ids, or None when zone_export_ids is not set.
        self.zone_selection = None

    def parse_zone_export_ids(self):
        """Validate zone_export_ids and return {zone: (export IDs, exclude)}, or None when it is not set.

        "1,3" collects only these export IDs of the zone, "-2,-4" collects every export of the zone except these
        export IDs, and "" collects every export of the zone. All problems found are reported in one error.
        """
        zone_export_ids = self.instance.zone_export_ids
        if zone_export_ids is None:
            return None
        if not isinstance(zone_export_ids, dict):
            raise ConfigurationError(
                "zone_export_ids must be a mapping of access zone name to export IDs, for example {}, got {}.".format(
                    ZONE_EXPORT_IDS_EXAMPLE, type(zone_export_ids).__name__
                )
            )
        if not zone_export_ids:
            raise ConfigurationError(
                "zone_export_ids must contain at least one access zone, for example {}.".format(ZONE_EXPORT_IDS_EXAMPLE)
            )

        errors = []
        if self.instance.export_ids:
            errors.append("export_ids cannot be used together with zone_export_ids.")

        zone_selection = {}
        for zone, value in zone_export_ids.items():
            zone_name = self.parse_zone_name(zone, errors)
            if zone_name is None:
                continue
            if zone_name in zone_selection:
                errors.append("Access zone '{}' is configured more than once.".format(zone_name))
                continue
            if zone_name.casefold() in {configured.casefold() for configured in zone_selection}:
                self.instance.log.warning(
                    "Access zone '%s' in zone_export_ids differs only in case from another configured access zone.",
                    zone_name,
                )
            selection = self.parse_export_ids(zone_name, value, errors)
            if selection is not None:
                zone_selection[zone_name] = selection

        if errors:
            raise ConfigurationError("zone_export_ids is not valid:\n- " + "\n- ".join(errors))
        return zone_selection

    @staticmethod
    def parse_zone_name(zone, errors):
        """Return the access zone name, or None after adding the problem to errors."""
        if zone is None:
            errors.append("zone_export_ids contains an empty access zone name.")
            return None
        if isinstance(zone, bool) or not isinstance(zone, (str, int)):
            errors.append("Invalid access zone name {!r}. Access zone names must be text.".format(zone))
            return None
        zone_name = str(zone).strip()
        if not zone_name:
            errors.append("zone_export_ids contains an empty access zone name.")
            return None
        if INVALID_ZONE_NAME_CHARACTERS.search(zone_name):
            errors.append(
                "Invalid access zone name {!r}. Access zone names cannot contain commas or control characters.".format(
                    zone_name
                )
            )
            return None
        return zone_name

    def parse_export_ids(self, zone, value, errors):
        """Return (export IDs, exclude) of one access zone, or None after adding the problems to errors.

        No export IDs means every export of the zone.
        """
        if value is None:
            return set(), False
        if isinstance(value, bool) or not isinstance(value, (str, int)):
            errors.append(
                "Invalid value {!r} for access zone '{}'. Expected export IDs as a string, for example "
                '"1,3", "-2" or "".'.format(value, zone)
            )
            return None

        collect_ids = set()
        exclude_ids = set()
        invalid_tokens = []
        for token in filter(None, (token.strip() for token in str(value).split(","))):
            if not EXPORT_ID_TOKEN.fullmatch(token) or int(token) == 0:
                invalid_tokens.append(token)
                continue
            export_id = str(abs(int(token)))
            ids = exclude_ids if token.startswith("-") else collect_ids
            if export_id in ids:
                self.instance.log.warning("Export ID %s of access zone '%s' is listed more than once.", export_id, zone)
            ids.add(export_id)

        if invalid_tokens:
            errors.append(
                "Invalid export ID(s) {} for access zone '{}'. Use a positive integer to collect an export ID "
                "(for example 2), or a negative integer to exclude it (for example -2).".format(
                    ", ".join("'{}'".format(token) for token in invalid_tokens), zone
                )
            )
            return None
        if collect_ids and exclude_ids:
            errors.append(
                "Access zone '{}' has both export IDs to collect ({}) and export IDs to exclude ({}). Use either "
                "export IDs to collect, or negative export IDs to exclude.".format(
                    zone, ",".join(sorted(collect_ids, key=int)), ",".join(sorted(exclude_ids, key=int))
                )
            )
            return None
        return (exclude_ids, True) if exclude_ids else (collect_ids, False)

    def get_required_dataset_metrics(self):
        """Export IDs are unique only within an access zone, so a dataset must also track zone_name per zone."""
        return ["export_id", "zone_name"] if self.zone_selection else ["export_id"]

    def is_valid_dataset(self, dataset_dict):
        metrics = dataset_dict.get("metrics", [])
        return all(metric in metrics for metric in self.get_required_dataset_metrics())

    def filter_datasets_by_ids(self, datasets):
        self.instance.dataset_list = [x.strip() for x in self.instance.dataset_ids.split(",")]
        self.instance.dataset_list = list(filter(None, self.instance.dataset_list))
        for dataset_dict in datasets:
            for dataset in self.instance.dataset_list:
                if str(dataset_dict["id"]) == dataset and self.is_valid_dataset(dataset_dict):
                    self.instance.valid_dataset.append(dataset)

    def filter_valid_datasets(self, datasets):
        self.instance.valid_dataset = []
        if self.instance.dataset_ids:
            self.filter_datasets_by_ids(datasets)
        else:
            for dataset in datasets:
                if self.is_valid_dataset(dataset):
                    self.instance.valid_dataset.append(str(dataset.get("id")))

    def validate_datasets(self):
        url = f"{self.instance.base_uri}/platform/14/performance/datasets"
        response_json = None
        try:
            response_json = self.instance._make_request(url)
        except Exception as exception:
            self.instance.log.exception(exception)
            raise exception

        if response_json is None:
            self.instance.log.error("%s %s", REQUEST_FAILED_MESSAGE, url)
            raise Exception("%s %s", REQUEST_FAILED_MESSAGE, url)

        datasets = response_json.get("datasets", [])
        if not datasets:
            self.instance.log.error("No datasets found for : %s", url)
            raise Exception("No datasets found for : %s", url)

        self.filter_valid_datasets(datasets)

        if not self.instance.valid_dataset:
            required_metrics = ", ".join(self.get_required_dataset_metrics())
            self.instance.log.error("No datasets found having metrics: %s", required_metrics)
            raise ValueError("No datasets found having metrics: {}".format(required_metrics))

    def build_zone_export_path_map(self):
        """Return {(zone, export_id): paths} of the exports selected in zone_export_ids."""
        export_path_map = {}
        for zone, (export_ids, exclude) in self.zone_selection.items():
            url = f"{self.instance.base_uri}/platform/14/protocols/nfs/exports?zone={quote(zone, safe='')}"
            try:
                response_json = self.instance._make_request(url)
            except Exception as exception:
                self.instance.log.error("Could not fetch NFS exports of access zone '%s': %s", zone, exception)
                continue
            if response_json is None:
                self.instance.log.error("%s %s", REQUEST_FAILED_MESSAGE, url)
                continue

            exports = [export for export in response_json.get("exports", []) if export.get("id") is not None]
            if not exports:
                self.instance.log.warning("No NFS exports found in access zone '%s'.", zone)
                continue

            zone_exports = {str(export["id"]): export for export in exports}
            missing_ids = export_ids - set(zone_exports)
            if missing_ids:
                self.instance.log.warning(
                    "Export ID(s) %s of access zone '%s' in zone_export_ids were not found in that access zone.",
                    ",".join(sorted(missing_ids, key=int)),
                    zone,
                )
            if not export_ids:
                selected_ids = set(zone_exports)
            elif exclude:
                selected_ids = set(zone_exports) - export_ids
            else:
                selected_ids = set(zone_exports) & export_ids
            if not selected_ids:
                self.instance.log.warning("No NFS exports of access zone '%s' are selected for collection.", zone)

            for export_id in selected_ids:
                export = zone_exports[export_id]
                # Use the access zone name reported by OneFS, as it is the name the statistics rows carry.
                export_path_map[(export.get("zone") or zone, export_id)] = export.get("paths", [])

        if not export_path_map:
            self.instance.log.error("No NFS exports found in access zone(s) of zone_export_ids.")
            raise ValueError("No NFS exports found in access zone(s) of zone_export_ids.")
        return export_path_map

    def build_export_path_map(self):
        if self.zone_selection:
            return self.build_zone_export_path_map()
        url = f"{self.instance.base_uri}/platform/14/protocols/nfs/exports"
        response_json = None
        try:
            response_json = self.instance._make_request(url)
        except Exception as exception:
            self.instance.log.exception(exception)
            raise exception

        if response_json is None:
            self.instance.log.error("%s %s", REQUEST_FAILED_MESSAGE, url)
            raise Exception("%s %s", REQUEST_FAILED_MESSAGE, url)

        exports = response_json.get("exports", [])
        if not exports:
            self.instance.log.error("No exports found for : %s", url)
            raise Exception("No exports found for : %s", url)
        export_path_map = {}
        if not self.instance.export_ids:
            for export in exports:
                export_path_map.update({(DEFAULT_NFS_ZONE, str(export.get("id"))): export.get("paths", [])})
        else:
            self.instance.export_list = [x.strip() for x in self.instance.export_ids.split(",")]
            self.instance.export_list = list(filter(None, self.instance.export_list))
            for export in self.instance.export_list:
                export_path_map.update(
                    {
                        (DEFAULT_NFS_ZONE, export): export_path["paths"]
                        for export_path in exports
                        if export == str(export_path["id"])
                    }
                )
            if not export_path_map:
                self.instance.log.error("No such exports found. Please provide valid export_ids.")
                raise ValueError("No exports found. Please provide valid export_ids.")
        return export_path_map

    def fetch_response_stats(self, api, export_path_map):
        response_stats = []
        export_ids = sorted({export_id for _, export_id in export_path_map}, key=int)
        for id in self.instance.valid_dataset:
            url = f"{self.instance.base_uri}{api.get('api_url', '')}?dataset={id}&export_ids={','.join(export_ids)}"
            if self.zone_selection:
                zone_names = sorted({quote(zone, safe="") for zone, _ in export_path_map})
                url = f"{url}&zone_names={','.join(zone_names)}"
            try:
                response = self.instance._make_request(url)
            except Exception as exception:
                self.instance.log.exception(exception)
                raise exception

            if response is None:
                self.instance.log.error("Request Failed of url : %s", url)
                continue
            response_data = response.get("workload", [])
            for response_dict in response_data:
                response_dict.update({"dataset_id": id, "cluster_name": self.instance.cluster_name})
            response_stats.extend(response_data)
        return response_stats

    def get_stats_and_export_path_map(self, api):
        self.zone_selection = self.parse_zone_export_ids()
        self.validate_datasets()
        export_path_map = self.build_export_path_map()
        response_stats = self.fetch_response_stats(api, export_path_map)
        return response_stats, export_path_map

    def ingest_stats_params(self, api):
        response_stats, export_path_map = self.get_stats_and_export_path_map(api)

        cds_dell_emc_helper_class_ = self.instance.get_helper_class(api)
        for panel in api.get("dashboard_panels", []):
            panel_to_call = getattr(cds_dell_emc_helper_class_(self), panel)
            if panel_to_call is not None:
                try:
                    metrics_list = panel_to_call(response_stats, export_path_map)
                    for metric in metrics_list:
                        tags = metric[2] + self.instance._tags
                        self.instance.gauge(metric[0], metric[1], tags=tags)
                except Exception as exception:
                    error = "Error occurred while ingesting the data of {} panel.".format(panel)
                    self.instance.log.exception(error)
                    raise exception

                self.instance.log.info("Data for %s panel is ingested successfully.", panel)

    def nfs_export_bytes_in(self, response_stats, export_path_map):
        """Method to get NFS Export Bytes In Stats."""
        metrics_list = self.create_metrics(response_stats, export_path_map, "bytes_in")
        return metrics_list

    def nfs_export_bytes_out(self, response_stats, export_path_map):
        """Method to get NFS Export Bytes Out Stats."""
        metrics_list = self.create_metrics(response_stats, export_path_map, "bytes_out")
        return metrics_list

    def nfs_export_latency_read(self, response_stats, export_path_map):
        """Method to get NFS Export Latency Read Stats."""
        metrics_list = self.create_metrics(response_stats, export_path_map, "latency_read")
        return metrics_list

    def nfs_export_latency_write(self, response_stats, export_path_map):
        """Method to get NFS Export Latency Write Stats."""
        metrics_list = self.create_metrics(response_stats, export_path_map, "latency_write")
        return metrics_list

    def nfs_export_reads(self, response_stats, export_path_map):
        """Method to get NFS Export Reads Stats."""
        metrics_list = self.create_metrics(response_stats, export_path_map, "reads")
        return metrics_list

    def nfs_export_ops(self, response_stats, export_path_map):
        """Method to get NFS Export Ops Stats."""
        metrics_list = self.create_metrics(response_stats, export_path_map, "ops")
        return metrics_list

    def nfs_export_cpu(self, response_stats, export_path_map):
        """Method to get NFS Export CPU Stats."""
        metrics_list = self.create_metrics(response_stats, export_path_map, "cpu")
        return metrics_list

    def nfs_export_writes(self, response_stats, export_path_map):
        """Method to get NFS Export Writes Stats."""
        metrics_list = self.create_metrics(response_stats, export_path_map, "writes")
        return metrics_list

    def create_metrics(self, response_stats, export_path_map, key):
        metric_prefix = "{}{}".format(self.nfs_export_stats_prefix, key)
        metric_list = []
        for export_stats in response_stats:
            stats_value = export_stats.get(key)
            export_id = export_stats.get("export_id")
            if export_id is None:
                continue
            # The zone comes from the row itself, as the same export ID can exist in several access zones.
            zone = export_stats.get("zone_name") or DEFAULT_NFS_ZONE
            if (zone, str(export_id)) not in export_path_map:
                continue
            metric_list.append(
                [
                    metric_prefix,
                    stats_value,
                    [
                        f"{INTEGRATION_PREFIX}export_id:{export_id}",
                        f"{INTEGRATION_PREFIX}path:{export_path_map.get((zone, str(export_id)))}",
                        f"{INTEGRATION_PREFIX}zone:{zone}",
                        f"{INTEGRATION_PREFIX}dataset_id:{export_stats.get('dataset_id')}",
                        f"{INTEGRATION_PREFIX}node:node-{export_stats.get('node')}",
                        f"{INTEGRATION_PREFIX}cluster:{export_stats.get('cluster_name')}",
                    ],
                ]
            )

        return metric_list
